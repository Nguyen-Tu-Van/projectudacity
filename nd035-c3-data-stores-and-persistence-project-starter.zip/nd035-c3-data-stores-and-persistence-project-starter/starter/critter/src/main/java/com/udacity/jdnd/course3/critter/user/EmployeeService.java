package com.udacity.jdnd.course3.critter.user;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.transaction.Transactional;

@Transactional
@Service
public class EmployeeService {
    @Autowired
    EmployeeRepository employeeRepo;

    public EmployeeDTO saveEmployee(EmployeeDTO employeeDTO) {
        // convert employeeDTO to employee and add employee into database
        Employee employee = employeeRepo.save(ConvertEmployeeDTOToEntity(employeeDTO));
        return ConvertEntityToEmployeeDTO(employee);
    }

    private EmployeeDTO ConvertEntityToEmployeeDTO(Employee employee) {
        EmployeeDTO employeeDTO = new EmployeeDTO();
        BeanUtils.copyProperties(employee,employeeDTO);
        return employeeDTO;
    }

    private Employee ConvertEmployeeDTOToEntity(EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        BeanUtils.copyProperties(employeeDTO, employee);
        return employee;
    }

    public EmployeeDTO getEmployee(long employeeId) {
        // get Employee from DB h2 by ID
        Optional<Employee> optional = employeeRepo.findById(employeeId);
        if(optional.isPresent()) return ConvertEntityToEmployeeDTO(optional.get());
        throw new NullPointerException();
    }

    public void setAvailability(Set<DayOfWeek> daysAvailable, long employeeId) {
        Optional<Employee> optional = employeeRepo.findById(employeeId);
        if(optional.isPresent())
        {
            Employee e = optional.get();
            e.setDaysAvailable(daysAvailable);
            employeeRepo.save(e);
        }
        else throw new NullPointerException();
    }

    public List<EmployeeDTO> findEmployeesForService(EmployeeRequestDTO employeeDTO) {
        // get Employee list bey skill and dayOfWeek
        Set<EmployeeSkill> skills = employeeDTO.getSkills();
        DayOfWeek dayOfWeek = employeeDTO.getDate().getDayOfWeek();
        List<Employee> employeeList = employeeRepo.findAllByDaysAvailable(dayOfWeek);
        List<EmployeeDTO> employeeDTOList = new ArrayList<>();
        for(Employee employee : employeeList)
            if(employee.getSkills().containsAll(skills)) employeeDTOList.add(ConvertEntityToEmployeeDTO(employee));

        return employeeDTOList;
    }
}
