package com.udacity.jdnd.course3.critter.schedule;

import com.udacity.jdnd.course3.critter.pet.Pet;
import com.udacity.jdnd.course3.critter.pet.PetRepository;
import com.udacity.jdnd.course3.critter.user.Customer;
import com.udacity.jdnd.course3.critter.user.CustomerRepository;
import com.udacity.jdnd.course3.critter.user.Employee;
import com.udacity.jdnd.course3.critter.user.EmployeeRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.*;

@Transactional
@Service
public class ScheduleService {
    @Autowired
    ScheduleRepository scheduleRepo;
    @Autowired
    PetRepository petRepo;
    @Autowired
    EmployeeRepository employeeRepo;
    @Autowired
    CustomerRepository customerRepo;

    public ScheduleDTO save(ScheduleDTO scheduleDTO) {
        // convert schedule DTO to schedule and add schedule into database
        Schedule schedule = convertScheduleDTOToEntity(scheduleDTO);
        schedule = scheduleRepo.save(schedule);

        return convertEntityToScheduleDTO(schedule);
    }

    private ScheduleDTO convertEntityToScheduleDTO(Schedule schedule) {
        ScheduleDTO scheduleDTO = new ScheduleDTO();
        BeanUtils.copyProperties(schedule, scheduleDTO);

        // add pet into schedule
        if(schedule.getPets() != null)
        {
            List<Long> petList = new ArrayList<>();
            schedule.getPets().forEach(pet -> petList.add(pet.getId()));
            scheduleDTO.setPetIds(petList);
        }

        // add employee into schedule
        if(schedule.getEmployees() != null)
        {
            List<Long> employeeList = new ArrayList<>();
            schedule.getEmployees().forEach(employee -> employeeList.add(employee.getId()));
            scheduleDTO.setEmployeeIds(employeeList);
        }

        return scheduleDTO;
    }

    private Schedule convertScheduleDTOToEntity(ScheduleDTO scheduleDTO) {
        Schedule schedule = new Schedule();
        BeanUtils.copyProperties(scheduleDTO, schedule);

        // add petDTO into schedule
        if(scheduleDTO.getPetIds() != null){
            Set<Pet> petList = new HashSet<>();
            scheduleDTO.getPetIds().forEach(petId -> petList.add(petRepo.findById(petId).get()));
            schedule.setPets(petList);
        }
        // add employeeDTO into schedule
        if(scheduleDTO.getEmployeeIds() != null){
            Set<Employee> employeeList = new HashSet<>();
            scheduleDTO.getEmployeeIds().forEach(employeeId -> employeeList.add(employeeRepo.findById(employeeId).get()));
            schedule.setEmployees(employeeList);
        }

        return schedule;
    }

    public List<ScheduleDTO> getAllSchedules() {
        // get All schedule from DB h2
        List<Schedule> scheduleList = scheduleRepo.findAll();
        List<ScheduleDTO> scheduleDTOList = new ArrayList<>();

        //convert scheduleList -> scheduleDTOList
        for(Schedule schedule:scheduleList) scheduleDTOList.add(convertEntityToScheduleDTO(schedule));

        return scheduleDTOList;
    }

    public List<ScheduleDTO> findScheduleByPetId(long petId) {
        Optional<Pet> optional= petRepo.findById(petId);
        if(optional.isPresent())
        {
            // get Schedule list from pet
            List<Schedule> scheduleList = scheduleRepo.findAllByPetsContaining(optional.get());
            List<ScheduleDTO> scheduleDTOList = new ArrayList<>();
            for(Schedule schedule : scheduleList) scheduleDTOList.add(convertEntityToScheduleDTO(schedule));
            return scheduleDTOList;
        }
        throw new NullPointerException();
    }

    public List<ScheduleDTO> findScheduleByEmployeeId(long employeeId) {
        Optional<Employee> optional= employeeRepo.findById(employeeId);
        if(optional.isPresent())
        {
            // get Schedule list from employee
            List<Schedule> scheduleList = scheduleRepo.findAllByEmployeesContaining(optional.get());
            List<ScheduleDTO> scheduleDTOList = new ArrayList<>();
            for(Schedule schedule : scheduleList) scheduleDTOList.add(convertEntityToScheduleDTO(schedule));
            return scheduleDTOList;
        }
        throw new NullPointerException();
    }

    public List<ScheduleDTO> getScheduleForCustomerId(long customerId) {
        Optional<Customer> optional = customerRepo.findById(customerId);
        if(optional.isPresent())
        {
            // get Schedule list from Customer
            List<Pet> petList = optional.get().getPets();
            List<Schedule> scheduleList = scheduleRepo.findAllByPetsIn(petList);
            List<ScheduleDTO> scheduleDTOList = new ArrayList<>();
            for (Schedule schedule:scheduleList) scheduleDTOList.add(convertEntityToScheduleDTO(schedule));
            return scheduleDTOList;
        }
        throw new NullPointerException();
    }
}
