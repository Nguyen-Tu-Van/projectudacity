package com.udacity.jdnd.course3.critter.pet;

import com.udacity.jdnd.course3.critter.user.Customer;
import com.udacity.jdnd.course3.critter.user.CustomerRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;

@Transactional
@Service
public class PetService {
    @Autowired
    PetRepository petRepo;
    @Autowired
    CustomerRepository customerRepo;

    public PetDTO save(PetDTO petDTO) {
        // convert pet DTO to pet and add pet into database
        Pet pet = petRepo.save(convertPetDTOToEntity(petDTO));
        Customer customer = pet.getCustomer();
        if(customer!=null)
        {
            customer.addPet(pet);
            customerRepo.save(customer);
        }
        return  convertEntityToPetDTO(pet);
    }

    private PetDTO convertEntityToPetDTO(Pet pet) {
        PetDTO petDTO = new PetDTO();
        BeanUtils.copyProperties(pet, petDTO);
        if(pet.getCustomer() != null) petDTO.setOwnerId(pet.getCustomer().getId());

        return petDTO;
    }

    private Pet convertPetDTOToEntity(PetDTO petDTO) {
        Pet pet = new Pet();
        BeanUtils.copyProperties(petDTO, pet);
        if(petDTO.getOwnerId() != 0) pet.setCustomer(customerRepo.findById(petDTO.getOwnerId()).get());

        return pet;
    }

    public PetDTO getPetById(long petId) {
        Optional<Pet> optional = petRepo.findById(petId);
        if(optional.isPresent()) return convertEntityToPetDTO(optional.get());

        throw new NullPointerException();
    }

    public List<PetDTO> getPets() {
        // get all pet from DB h2
        List<Pet> petList = petRepo.findAll();
        List<PetDTO> petDTOList = new ArrayList<>();
        for(Pet pet:petList) petDTOList.add(convertEntityToPetDTO(pet));

        return petDTOList;
    }

    public List<PetDTO> getPetByOwnerId(long ownerId) {
        // get pet list from customer ID
        Optional<Customer> optional = customerRepo.findById(ownerId);
        if(!optional.isPresent()) throw new NullPointerException();
        List<Pet> petList = petRepo.findAllPetByCustomerId(ownerId);
        List<PetDTO> petDTOList = new ArrayList<>();
        for(Pet pet : petList){
            petDTOList.add(convertEntityToPetDTO(pet));
        }
        return petDTOList;
    }
}
