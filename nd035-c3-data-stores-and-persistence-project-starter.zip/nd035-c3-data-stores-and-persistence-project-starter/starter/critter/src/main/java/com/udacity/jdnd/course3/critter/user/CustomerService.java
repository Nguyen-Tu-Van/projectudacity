package com.udacity.jdnd.course3.critter.user;

import com.udacity.jdnd.course3.critter.pet.Pet;
import com.udacity.jdnd.course3.critter.pet.PetRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;

@Transactional
@Service
public class CustomerService {
    @Autowired
    CustomerRepository customerRepo;
    @Autowired
    PetRepository petRepo;

    public CustomerDTO saveCustomer(CustomerDTO customerDTO) {
        // convert CustomerDTO to Customer and add Customer into database
        return convertEntityToCustomerDTO(customerRepo.save(convertCustomerDTOToEntity(customerDTO)));
    }

    private CustomerDTO convertEntityToCustomerDTO(Customer customer) {
        CustomerDTO customerDTO = new CustomerDTO();
        BeanUtils.copyProperties(customer, customerDTO);
        if(customer.getPets() != null)
        {
            List<Long> petList = new ArrayList<>();
            customer.getPets().forEach(pet -> petList.add(pet.getId()));
            customerDTO.setPetIds(petList);
        }
        return customerDTO;
    }

    private Customer convertCustomerDTOToEntity(CustomerDTO customerDTO) {
        Customer customer = new Customer();
        BeanUtils.copyProperties(customerDTO, customer);
        if(customerDTO.getPetIds() != null)
        {
            List<Pet> petList = new ArrayList<>();
            customerDTO.getPetIds().forEach(petId -> petList.add(petRepo.findById(petId).get()));
            customer.setPets(petList);
        }
        return customer;
    }

    public List<CustomerDTO> getAllCustomers() {
        List<Customer> customerList = customerRepo.findAll();
        if(customerList != null)
        {
            // get all Customer from DB h2
            List<CustomerDTO> customerDTOList = new ArrayList<>();
            for(Customer customer :customerList) customerDTOList.add(convertEntityToCustomerDTO(customer));
            return customerDTOList;
        }
        throw new NullPointerException();
    }

    public CustomerDTO getOwnerByPet(long petId) {
        Optional<Pet> optional = petRepo.findById(petId);
        if(optional.isPresent())
        {
            // get Customer list by pet
            Optional<Customer> customerOptional = customerRepo.findById(optional.get().getCustomer().getId());
            if(customerOptional.isPresent()) return convertEntityToCustomerDTO(customerOptional.get());
        }
        throw new NullPointerException();
    }
}
