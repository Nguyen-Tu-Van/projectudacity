package com.udacity.jdnd.course3.critter.pet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Handles web requests related to Pets.
 */
@RestController
@RequestMapping("/pet")
public class PetController {
    @Autowired
    PetService pet;

    @PostMapping
    public PetDTO savePet(@RequestBody PetDTO petDTO) {
        return pet.save(petDTO);
    }
    @GetMapping("/{petId}")
    public PetDTO getPet(@PathVariable long petId) {
        return pet.getPetById(petId);
    }

    @GetMapping
    public List<PetDTO> getPets(){
        return pet.getPets();
    }

    @GetMapping("/owner/{ownerId}")
    public List<PetDTO> getPetsByOwner(@PathVariable long ownerId) {
        return pet.getPetByOwnerId(ownerId);
    }
}
